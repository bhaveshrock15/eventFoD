package com.pgroup5.eventbackend.daoimpl;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pgroup5.eventbackend.dao.CategoryDAO;
import com.pgroup5.eventbackend.dto.Category;


@Repository("categoryDAO")
@Transactional
public class CategoryDAOImpl implements CategoryDAO {

	@Autowired
	private SessionFactory sessionFactory;
	
	private static List<Category> categories =new ArrayList<Category>();
	
	/*static {
		
		Category c =new Category();
		
		//Adding fisrt Category
		c.setId(1);
		c.setCategoryName("Bllod donation");
		c.setDescription("Blood Dobnation Description come here");
		c.setImageURL("cat_1.png");
		
		categories.add(c);
		
		//2nd
		
		c =new Category();
		
		//Adding fisrt Category
		c.setId(2);
		c.setCategoryName("pani foundatiojn");
		c.setDescription("pani foundation Description come here");
		c.setImageURL("cat_2.png");
		
		categories.add(c);
		//3rd
		
				c =new Category();
				
				//Adding fisrt Category
				c.setId(3);
				c.setCategoryName("plant farming");
				c.setDescription("plant farmoing Description come here");
				c.setImageURL("cat_3.png");
				
				categories.add(c);
				
				c =new Category();
				
				c.setId(4);
				c.setCategoryName("Bllod donation");
				c.setDescription("Blood Dobnation Description come here");
				c.setImageURL("cat_1.png");
				
				
		
		categories.add(c);
		
		
	}*/
	
	
	public List<Category> list() {
			String selectActiveCategory = "FROM Category WHERE active = :active";
		
		Query query = sessionFactory.getCurrentSession().createQuery(selectActiveCategory);
				
		query.setParameter("active", true);
						
		return query.getResultList();
	}


	public Category get(int id) {

		//foreach for retrieve single category based on id
		
		return sessionFactory.getCurrentSession().get(Category.class, Integer.valueOf(id));

	}

	@Transactional
	public boolean add(Category category) {

		try {
			//Add category to datbase
			
			sessionFactory.getCurrentSession().persist(category);
			
			return true;
		}
		catch(Exception e) {
			
			e.printStackTrace();
			return false;
		}
		
		
	
	}

}
