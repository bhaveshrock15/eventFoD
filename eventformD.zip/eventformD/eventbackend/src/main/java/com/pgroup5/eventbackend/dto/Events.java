package com.pgroup5.eventbackend.dto;

import java.util.Date;
import java.util.UUID;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
@Component
@Entity
public class Events {

	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	private String code;
	//@NotBlank(message = "Please enter the product name!")
	private String name;
	//@NotBlank(message = "Please enter the brand name!")
	private String location;
	//@NotBlank(message = "Please enter the description!")
	private String description;
	//@Min(value = 1, message="Please select at least one value!")
	@Column(name = "from_date")
	private String fromDate;
	
	@Column(name = "to_date")
	private String toDate;
	

	@Column(name = "is_active")	
	private boolean active;
	
	@Column(name = "category_id")
//	@JsonIgnore
	private int categoryId;
	
	@Column(name = "supplier_id")
	//@JsonIgnore
	private int supplierId;
	private int attent;
	private int views;
	
	//defalut constructor
	public Events() {
		
		this.code = "PRD" + UUID.randomUUID().toString().substring(26).toUpperCase();
		
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getFromDate() {
		return fromDate;
	}

	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}

	public String getToDate() {
		return toDate;
	}

	public void setToDate(String toDate) {
		this.toDate = toDate;
	}

	public boolean isActive() {
		return active;
	}

	public void setActive(boolean active) {
		this.active = active;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public int getSupplierId() {
		return supplierId;
	}

	public void setSupplierId(int supplierId) {
		this.supplierId = supplierId;
	}

	public int getAttent() {
		return attent;
	}

	public void setAttent(int attent) {
		this.attent = attent;
	}

	public int getViews() {
		return views;
	}

	public void setViews(int views) {
		this.views = views;
	}

	@Override
	public String toString() {
		return "Event [id=" + id + ", code=" + code + ", name=" + name + ", location=" + location + ", description="
				+ description + ", fromDate=" + fromDate + ", toDate=" + toDate + ", active=" + active + ", categoryId="
				+ categoryId + ", supplierId=" + supplierId + ", attent=" + attent + ", views=" + views + "]";
	}
	
	
	
}
