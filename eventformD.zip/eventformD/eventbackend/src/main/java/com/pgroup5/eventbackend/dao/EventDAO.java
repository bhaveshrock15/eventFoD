package com.pgroup5.eventbackend.dao;

import java.util.List;

import com.pgroup5.eventbackend.dto.Events;

public interface EventDAO {
	
	Events get(int eventId);
	List<Events> list();	
	boolean add(Events event);
	boolean update(Events event);
	boolean delete(Events event);

	//List<Product> getProductsByParam(String param, int count);	
	
	
	// business methods
	List<Events> listActiveEvents();	
	List<Events> listActiveEventsByCategory(int categoryId);
	List<Events> getLatestActiveEvents(int count);

}
