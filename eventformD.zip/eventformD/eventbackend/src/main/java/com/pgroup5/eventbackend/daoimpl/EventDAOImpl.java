package com.pgroup5.eventbackend.daoimpl;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.pgroup5.eventbackend.dao.EventDAO;
import com.pgroup5.eventbackend.dto.Events;

@Repository("EventDAO")
@Transactional
//coz all method run inside a transaction which is managed by spring framework
public class EventDAOImpl implements EventDAO {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	//Single event
	public Events get(int eventId) {
		
		try {
			return sessionFactory.getCurrentSession().get(Events.class,Integer.valueOf(eventId));
			
		}catch(Exception e) {
			e.printStackTrace();
		}
		return null;

	}

	
	//List of event
	
	public List<Events> list() {
		return sessionFactory
				.getCurrentSession()
					.createQuery("FROM Events" , Events.class)
						.getResultList();
	}

	
	//insert a event
	public boolean add(Events event) {
		try {			
			sessionFactory
					.getCurrentSession()
						.persist(event);
			return true;
		}
		catch(Exception ex) {		
			ex.printStackTrace();			
		}		
		return false;
	}

	
	//update a event
	public boolean update(Events event) {
		try {			
			sessionFactory
					.getCurrentSession()
						.update(event);
			return true;
		}
		catch(Exception ex) {		
			ex.printStackTrace();			
		}		
		return false;		
	}

	
	//delete a event temporaroly
	
	public boolean delete(Events event) {
		try {
			event.setActive(false);
			// call the update method
			return this.update(event);
		}
		catch(Exception ex) {		
			ex.printStackTrace();			
		}		
		return false;		
	}

	//active -- this is field name inside event class
	//:active -- this is parameter name that we set below
	//ie setParameter method
	
	public List<Events> listActiveEvents() {
		String selectActiveEvents = "FROM Events WHERE active = :active";
		return sessionFactory
				.getCurrentSession()
					.createQuery(selectActiveEvents, Events.class)
						.setParameter("active", true)
							.getResultList();
	}

	public List<Events> listActiveEventsByCategory(int categoryId) {
		String selectActiveEventsByCategory = "FROM Events WHERE active = :active AND categoryId = :categoryId";
		return sessionFactory
				.getCurrentSession()
					.createQuery(selectActiveEventsByCategory, Events.class)
						.setParameter("active", true)
						.setParameter("categoryId",categoryId)
							.getResultList();
	}

	public List<Events> getLatestActiveEvents(int count) {
		return sessionFactory
				.getCurrentSession()
					.createQuery("FROM Events WHERE active = :active ORDER BY id", Events.class)
						.setParameter("active", true)
							.setFirstResult(0)
							.setMaxResults(count)
								.getResultList();			
	}

}
