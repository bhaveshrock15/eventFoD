$(function() {
	
	//Solving the active menu (navbar) problem

	switch(menu) {
	
	case 'About Us':
		$('#about').addClass('active');
		break;
	
	case 'Contact Us':
		$('#contact').addClass('active');
		break;
		
	case 'Manage Events':
		$('#manageEvents').addClass('active');
		break;
		
	case 'All Events':
		$('#listEvents').addClass('active');
		break;
		
	default:
		$('#listEvents').addClass('active');
		$('#a_'+ menu).addClass('active');
		break;

	}
	
	
	
	//code for jquery datatable
	//create dataset
	
	/*var events=[
		['1','ABC'],
		['2','BCD'],
		['3','EFC'],
		['4','ZYC'],
		['5','CFG'],
		['6','VBN']
	];*/
	
	var $table = $('#eventListTable');

	// execute the below code only where we have this table
	if ($table.length) {
		
		var jsonUrl = '';
		if (window.categoryId == '') {
			jsonUrl = window.contextRoot + '/json/data/all/events';
		} else {
			jsonUrl = window.contextRoot + '/json/data/category/'
					+ window.categoryId + '/events';
		}

		
		$table.DataTable({
			//data: events
			

				lengthMenu : [ [ 3, 5, 10, -1 ],
						[ '3 Records', '5 Records', '10 Records', 'ALL' ] ],
				pageLength : 5,
				ajax : {
					url : jsonUrl,
					dataSrc : ''
				},
				columns : [
						{
							data : 'code',
							bSortable : false,
							mRender : function(data, type, row) {

								return '<img src="' + window.contextRoot
										+ '/resources/images/' + data
										+ '.jpg" class="dataTableImg"/>';
						}
						},
						{
							data: 'name',
						},
						{
							data: 'location',
						},
						{
							data: 'fromDate',
						},
						{
							data: 'toDate',
						},
						{
							data: 'id',
							bsortable: false,
							mRender: function(data,type,row){
								var str= '';
								str += '<a href="' + window.contextRoot + '/show/'+data+'/event" class="btn btn-primary"><span class="glyphicon glyphicon-eye-open"></span></a>'
							return str;
							}
						}
						]
			
		});
		// console.log('Inside the table!');
	}
	
	var $alert = $('.alert');
	
	if($alert.length){
		
		setTimeout(function(){
			 $alert.fadeOut('slow');
		},3000)
	}
	
});