package com.pgroup5.event.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.pgroup5.eventbackend.dao.EventDAO;
import com.pgroup5.eventbackend.dto.Events;



@Controller
@RequestMapping("/json/data")
public class JsonDataController {

	@Autowired
	private EventDAO eventDAO;
	

	
	@RequestMapping("/all/events")
	@ResponseBody
	public List<Events> getAllEvents() {
		
		return eventDAO.listActiveEvents();
				
	}
	
	@RequestMapping("/category/{id}/events")
	@ResponseBody
	public List<Events> getEventsByCategory(@PathVariable int id) {
		
		return eventDAO.listActiveEventsByCategory(id);
				
	}
	
	
}
