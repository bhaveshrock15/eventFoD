package com.pgroup5.event.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.pgroup5.eventbackend.dao.CategoryDAO;
import com.pgroup5.eventbackend.dao.EventDAO;
import com.pgroup5.eventbackend.dto.Category;
import com.pgroup5.eventbackend.dto.Events;

@Controller
@RequestMapping("/manage")
public class ManagementController {
	
	@Autowired
	private CategoryDAO categoryDAO;
	
	@Autowired
	private EventDAO eventDAO;
	
	@RequestMapping(value="/events",method=RequestMethod.GET)
	public ModelAndView showManageEvents(@RequestParam(name="operation",required=false) String operation) {
		ModelAndView mv = new ModelAndView("page");	
		mv.addObject("title","Event Management");		
		mv.addObject("userClickManageEvent",true);
		
		Events nevent=new Events();
		
		nevent.setSupplierId(2);
		nevent.setActive(true);
		
		mv.addObject("event",nevent);
		
		if(operation!=null) {
			if(operation.equals("event")) {
				
				mv.addObject("message","Event Added Succesfully");
			}
			
		}
		
		return mv;
	}
	
	
	//handling event submission
	//return type string becoz we redirect url
	@RequestMapping(value="/events",method=RequestMethod.POST)
	public String handleEventSubmission(@ModelAttribute("event") Events mEvent) {
		
		//create new Event record
		eventDAO.add(mEvent);
		return "redirect:/manage/events?operation=event";
	}
	
//Returning categories for all requestmapping
	@ModelAttribute("categories")
	public List<Category> getcategories(){
		
		return categoryDAO.list();
	}	
}
